//
//  CollectionViewCell.swift
//  Notes1
//
//  Created by Gev Darbinyan on 09/07/2019.
//  Copyright © 2019 com.inYerevan. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet private weak var noteImageView: UIImageView?

}
